# Meet Elixir

Install Erlang and Elixir. There are graphical installers available:

- https://www.erlang-solutions.com/downloads/download-erlang-otp
- http://elixir-lang.org/packages.html

## Run tests

Run the tests for the `streamers` project by running:

    mix test
    
